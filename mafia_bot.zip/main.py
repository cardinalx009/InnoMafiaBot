from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ChatPermissions
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes, CallbackQueryHandler
import random
import os
import logging
from dotenv import load_dotenv
from typing import Dict, List, Optional

# Enable logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Game states
games = {}  # Chat ID -> Game instance

class Player:
    def __init__(self, id: int, name: str, username: Optional[str] = None):
        self.id = id
        self.name = name
        self.username = username or name
        self.role = None
        self.is_alive = True
        self.vote = None
        self.protected = False
        self.investigated = False
        
    def __str__(self):
        return self.name

class Game:
    def __init__(self, chat_id: int):
        self.chat_id = chat_id
        self.players: List[Player] = []
        self.started = False
        self.phase = "waiting"  # waiting, night, day
        self.roles = {}  # Player ID -> Role
        self.votes = {}  # Player ID -> Voted Player ID
        self.mafia_votes = {}  # Player ID -> Voted Player ID
        self.doctor_target = None  # Protected Player ID
        self.detective_target = None  # Investigated Player ID
        self.day_count = 0
        self.night_count = 0
        self.game_mode = "classic"  # classic, chaos
        self.special_roles = []  # spy, traitor, hunter, lover
        
    def get_alive_players(self) -> list[Player]:
        """Get list of alive players"""
        return [p for p in self.players if p.is_alive]

    def get_player_by_id(self, player_id: int) -> Player | None:
        """Get player by ID"""
        return next((p for p in self.players if p.id == player_id), None)
        
    def get_players_by_role(self, role: str) -> list[Player]:
        """Get all players with specified role"""
        return [p for p in self.players if self.roles.get(p.id) == role and p.is_alive]
        
    def assign_roles(self):
        num_players = len(self.players)
        if num_players < 3:
            return False
            
        roles = []
        if self.game_mode == "classic":
            # Basic roles
            num_mafia = max(1, num_players // 4)
            roles = ['Mafia'] * num_mafia
            roles.extend(['Doctor', 'Detective'])
            roles.extend(['Villager'] * (num_players - len(roles)))
        elif self.game_mode == "chaos":
            # Advanced roles
            num_mafia = max(1, num_players // 3)
            roles = ['Mafia'] * num_mafia
            special_roles = ['Doctor', 'Detective', 'Spy', 'Hunter', 'Traitor']
            roles.extend(special_roles[:min(len(special_roles), num_players - num_mafia)])
            roles.extend(['Villager'] * (num_players - len(roles)))
            
        random.shuffle(roles)
        for player, role in zip(self.players, roles):
            self.roles[player.id] = role
            
        return True

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Start command handler"""
    if not update.message:
        return
        
    await update.message.reply_text(
        "🎭 UltimateMafiaBot ga xush kelibsiz!\n\n"
        "O'yin boshlash uchun:\n"
        "1. /new - yangi o'yin yaratish\n"
        "2. /join - o'yinga qo'shilish\n"
        "3. /mode - o'yin rejimini tanlash (classic/chaos)\n"
        "4. Yetarlicha o'yinchi qo'shilgach, /startgame\n\n"
        "Qo'shimcha buyruqlar:\n"
        "/help - qo'llanma\n"
        "/rules - o'yin qoidalari\n"
        "/players - o'yinchilar ro'yxati\n"
        "/stats - statistika"
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Help command handler"""
    if not update.message:
        return
        
    await update.message.reply_text(
        "🎮 O'yin qoidalari:\n\n"
        "1. O'yin ikki fazadan iborat: Tun va Kun\n"
        "2. Tunda maxsus rollar o'z vazifalarini bajaradi:\n"
        "   - Mafia: /kill [ism] - o'ldirish\n"
        "   - Doktor: /heal [ism] - davolash\n"
        "   - Detektiv: /check [ism] - tekshirish\n"
        "3. Kunduzi hamma muhokama qilib ovoz beradi:\n"
        "   - /vote [ism] - ovoz berish\n\n"
        "Maxsus rollar (Chaos rejimida):\n"
        "- Spy 🕵️: Bir marta mafianing chatini ko'ra oladi\n"
        "- Hunter 🏹: O'ldirilganda bitta o'yinchini o'zi bilan olib ketadi\n"
        "- Traitor 🎭: Detektivga oddiy fuqarodek ko'rinadi"
    )

async def new_game(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Create a new game"""
    if not update.message:
        return
        
    chat_id = update.message.chat_id
    if chat_id in games:
        await update.message.reply_text("⚠️ Bu guruhda allaqachon o'yin mavjud!")
        return
        
    games[chat_id] = Game(chat_id)
    await update.message.reply_text(
        "🎮 Yangi o'yin yaratildi!\n"
        "O'yinga qo'shilish uchun /join buyrug'ini yuboring.\n"
        "O'yin rejimini tanlash uchun /mode buyrug'ini ishlating.\n"
        "O'yin boshlash uchun kamida 3 ta o'yinchi kerak."
    )

async def set_mode(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Set game mode"""
    if not update.message:
        return
        
    chat_id = update.message.chat_id
    if chat_id not in games:
        await update.message.reply_text("⚠️ Avval /new buyrug'i bilan yangi o'yin yarating!")
        return
        
    game = games[chat_id]
    if game.started:
        await update.message.reply_text("⚠️ O'yin boshlangandan so'ng rejimni o'zgartirib bo'lmaydi!")
        return
        
    keyboard = [
        [
            InlineKeyboardButton("Classic Mode 🎭", callback_data="mode_classic"),
            InlineKeyboardButton("Chaos Mode 🌪", callback_data="mode_chaos")
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text("O'yin rejimini tanlang:", reply_markup=reply_markup)

async def mode_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle mode selection callback"""
    query = update.callback_query
    if not query:
        return
        
    chat_id = query.message.chat_id
    if chat_id not in games:
        await query.answer("⚠️ O'yin topilmadi!")
        return
        
    game = games[chat_id]
    mode = query.data.split("_")[1]
    game.game_mode = mode
    
    await query.answer()
    await query.edit_message_text(
        f"✅ {mode.capitalize()} rejimi tanlandi!\n"
        "O'yinga qo'shilish uchun /join buyrug'ini yuboring."
    )

async def join_game(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Join the game"""
    if not update.message:
        return
        
    chat_id = update.message.chat_id
    user = update.message.from_user
    
    if chat_id not in games:
        await update.message.reply_text("⚠️ Bu guruhda hech qanday o'yin yo'q!\n/new buyrug'i bilan yangi o'yin yarating.")
        return
        
    game = games[chat_id]
    if game.started:
        await update.message.reply_text("⚠️ O'yin allaqachon boshlangan!")
        return
        
    if any(p.id == user.id for p in game.players):
        await update.message.reply_text("⚠️ Siz allaqachon o'yindasiz!")
        return
        
    player = Player(user.id, user.first_name, user.username)
    game.players.append(player)
    
    players_list = "\n".join([f"{i+1}. {p.name}" for i, p in enumerate(game.players)])
    
    await update.message.reply_text(
        f"✅ {user.first_name} o'yinga qo'shildi!\n\n"
        f"👥 Hozirgi o'yinchilar ({len(game.players)}):\n{players_list}"
    )

async def start_game(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Start the game"""
    if not update.message:
        return
        
    chat_id = update.message.chat_id
    if chat_id not in games:
        await update.message.reply_text("⚠️ Bu guruhda hech qanday o'yin yo'q!")
        return
        
    game = games[chat_id]
    if game.started:
        await update.message.reply_text("⚠️ O'yin allaqachon boshlangan!")
        return
        
    if len(game.players) < 3:
        await update.message.reply_text("⚠️ O'yin boshlash uchun kamida 3 ta o'yinchi kerak!")
        return
        
    # Assign roles
    if not game.assign_roles():
        await update.message.reply_text("⚠️ Rollarni taqsimlashda xatolik yuz berdi!")
        return
        
    game.started = True
    game.phase = "night"
    game.night_count = 1
    
    players_list = "\n".join([f"{i+1}. {p.name}" for i, p in enumerate(game.players)])
    
    await context.bot.send_message(
        chat_id=chat_id,
        text=f"🎮 O'yin boshlandi!\n\n"
             f"👥 O'yinchilar ({len(game.players)}):\n{players_list}\n\n"
             "Har bir o'yinchi o'z rolini bilish uchun botga shaxsiy xabar yozsin!"
    )
    
    # Send roles to players
    for player in game.players:
        role = game.roles[player.id]
        try:
            role_description = get_role_description(role)
            await context.bot.send_message(
                chat_id=player.id,
                text=f"🎭 Sizning rolingiz: {role}\n"
                     f"{role_description}\n"
                     f"O'yin {game.chat_id} guruhida o'ynalmoqda."
            )
        except Exception as e:
            logger.error(f"Error sending role to player {player.id}: {e}")
            await context.bot.send_message(
                chat_id=game.chat_id,
                text=f"⚠️ {player.name} bilan bog'lanib bo'lmadi. Iltimos, botga /start buyrug'ini yuboring."
            )
    
    await night_phase(context, game)

def get_role_description(role: str) -> str:
    """Get role description"""
    descriptions = {
        "Mafia": "🔪 Siz mafiyasiz! Har tun bitta o'yinchini o'ldira olasiz.\n/kill [ism] buyrug'i bilan o'ldiring",
        "Doctor": "💉 Siz doktorsiz! Har tun bitta o'yinchini qutqara olasiz.\n/heal [ism] buyrug'i bilan davolang",
        "Detective": "🔍 Siz detektivsiz! Har tun bitta o'yinchini tekshira olasiz.\n/check [ism] buyrug'i bilan tekshiring",
        "Villager": "👤 Siz oddiy fuqarosiz! Kunduzi muhokamada qatnashing va ovoz bering.",
        "Spy": "🕵️ Siz ayg'oqchisiz! Bir marta mafianing chatini ko'ra olasiz.\n/spy buyrug'i bilan ko'ring",
        "Hunter": "🏹 Siz ovchisiz! O'ldirilganingizda bitta o'yinchini o'zingiz bilan olib ketasiz.",
        "Traitor": "🎭 Siz xoinsiz! Detektivga oddiy fuqarodek ko'rinasiz, lekin mafiya tomondasiz."
    }
    return descriptions.get(role, "Role description not found")

async def restrict_chat(context: ContextTypes.DEFAULT_TYPE, game: Game, restrict: bool = True) -> None:
    """Restrict or unrestrict chat during night phase"""
    try:
        if restrict:
            permissions = ChatPermissions(
                can_send_messages=False,
                can_send_media_messages=False,
                can_send_polls=False,
                can_send_other_messages=False,
                can_add_web_page_previews=False,
                can_change_info=False,
                can_invite_users=True,
                can_pin_messages=False,
            )
        else:
            permissions = ChatPermissions(
                can_send_messages=True,
                can_send_media_messages=True,
                can_send_polls=True,
                can_send_other_messages=True,
                can_add_web_page_previews=True,
                can_change_info=False,
                can_invite_users=True,
                can_pin_messages=False,
            )
        
        await context.bot.set_chat_permissions(
            chat_id=game.chat_id,
            permissions=permissions
        )
    except Exception as e:
        logger.error(f"Error setting chat permissions: {e}")
        if restrict:
            await context.bot.send_message(
                chat_id=game.chat_id,
                text="⚠️ Guruh sozlamalarini o'zgartirib bo'lmadi. Iltimos, botga admin huquqlarini bering."
            )

async def night_phase(context: ContextTypes.DEFAULT_TYPE, game: Game) -> None:
    """Night phase handler"""
    game.phase = "night"
    game.mafia_votes.clear()
    game.doctor_target = None
    game.detective_target = None
    
    # Restrict chat during night
    await restrict_chat(context, game, True)
    
    await context.bot.send_message(
        chat_id=game.chat_id,
        text=f"🌙 Tun {game.night_count} boshlandi! Hamma uxlaydi...\n\n"
             "⚠️ Tun vaqtida guruhda yozish mumkin emas!"
    )
    
    # Send instructions to special roles
    for player in game.get_alive_players():
        role = game.roles.get(player.id)
        if role == "Mafia":
            await send_player_list_buttons(
                context, game.chat_id, player.id, "kill",
                exclude_self=True
            )
        elif role == "Doctor":
            await send_player_list_buttons(
                context, game.chat_id, player.id, "heal",
                exclude_self=False
            )
        elif role == "Detective":
            await send_player_list_buttons(
                context, game.chat_id, player.id, "check",
                exclude_self=True
            )

async def process_night_results(context: ContextTypes.DEFAULT_TYPE, game: Game) -> None:
    """Process night phase results"""
    # Count mafia votes
    vote_counts = {}
    for target_id in game.mafia_votes.values():
        vote_counts[target_id] = vote_counts.get(target_id, 0) + 1
    
    # Find target with most votes
    target_id = max(vote_counts.items(), key=lambda x: x[1])[0] if vote_counts else None
    target = game.get_player_by_id(target_id) if target_id else None
    
    # Check if target was protected
    protected = target_id == game.doctor_target if target else False
    
    # Allow chat messages again
    await restrict_chat(context, game, False)
    
    messages = []
    if target and not protected:
        target.is_alive = False
        messages.append(f"☠️ Tunda {target.name} o'ldirildi!")
        
        # Check if target was Hunter
        if game.roles.get(target_id) == "Hunter":
            # Let Hunter choose their target
            await send_player_list_buttons(
                context, game.chat_id, target_id, "hunter",
                exclude_self=True
            )
    elif target and protected:
        messages.append("🎭 Tunda kimdir o'ldirilmoqchi edi, lekin doktor uni qutqarib qoldi!")
    else:
        messages.append("🌙 Tun tinch o'tdi...")
    
    # Start day phase
    game.phase = "day"
    game.day_count += 1
    
    # Send night results
    await context.bot.send_message(
        chat_id=game.chat_id,
        text="\n".join(messages) + f"\n\n☀️ Kun {game.day_count} boshlandi! Muhokama vaqti..."
    )
    
    # Send vote buttons to all alive players
    alive_players = game.get_alive_players()
    for player in alive_players:
        await send_player_list_buttons(
            context, game.chat_id, player.id, "vote",
            exclude_self=True
        )

async def send_player_list_buttons(context: ContextTypes.DEFAULT_TYPE, chat_id: int, player_id: int, action: str, exclude_self: bool = True) -> None:
    """Send list of players as buttons"""
    game = games.get(chat_id)
    if not game:
        return
    
    buttons = []
    row = []
    for i, player in enumerate(game.get_alive_players()):
        if exclude_self and player.id == player_id:
            continue
            
        # Add player button to current row
        row.append(InlineKeyboardButton(
            f"{player.name} {'👑' if game.roles.get(player.id) == 'Mafia' else ''}", 
            callback_data=f"{action}_{player.id}"
        ))
        
        # Create new row after every 2 buttons
        if len(row) == 2:
            buttons.append(row)
            row = []
    
    # Add remaining buttons
    if row:
        buttons.append(row)
    
    # Add cancel button
    buttons.append([InlineKeyboardButton("❌ Bekor qilish", callback_data=f"{action}_cancel")])
    
    reply_markup = InlineKeyboardMarkup(buttons)
    
    action_texts = {
        "kill": "🔪 Kimni o'ldirmoqchisiz?",
        "heal": "💉 Kimni davolamoqchisiz?",
        "check": "🔍 Kimni tekshirmoqchisiz?",
        "vote": "🗳 Kimga ovoz bermoqchisiz?"
    }
    
    await context.bot.send_message(
        chat_id=player_id,
        text=action_texts.get(action, "Tanlang:"),
        reply_markup=reply_markup
    )

async def handle_player_action(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle player action callbacks"""
    query = update.callback_query
    if not query:
        return
    
    action, target_data = query.data.split("_")
    if target_data == "cancel":
        await query.edit_message_text("❌ Bekor qilindi")
        return
        
    user_id = query.from_user.id
    
    # Find the game where this player is participating
    current_game = None
    current_chat_id = None
    for chat_id, game in games.items():
        if any(p.id == user_id for p in game.players):
            current_game = game
            current_chat_id = chat_id
            break
    
    if not current_game:
        await query.answer("⚠️ Siz hech qaysi o'yinda qatnashmayapsiz!")
        return
    
    game = current_game
    if game.phase == "waiting":
        await query.answer("⚠️ O'yin hali boshlanmagan!")
        return
    
    target_id = int(target_data)
    target = game.get_player_by_id(target_id)
    if not target:
        await query.answer("⚠️ O'yinchi topilmadi!")
        return
        
    if not target.is_alive and action != "check":
        await query.answer("⚠️ Bu o'yinchi o'yinda emas!", show_alert=True)
        return
    
    user_role = game.roles.get(user_id)
    
    if action == "kill" and user_role == "Mafia":
        if game.phase != "night":
            await query.answer("⚠️ Faqat tunda o'ldira olasiz!", show_alert=True)
            return
            
        if target_id in game.mafia_votes.values():
            await query.answer("⚠️ Bu o'yinchi allaqachon tanlangan!", show_alert=True)
            return
            
        game.mafia_votes[user_id] = target_id
        await query.edit_message_text(f"🔪 Siz {target.name} ni o'ldirish uchun ovoz berdingiz")
        
        # Check if all mafia members have voted
        mafia_count = len(game.get_players_by_role("Mafia"))
        if len(game.mafia_votes) >= mafia_count:
            await check_night_end(context, game)
        
    elif action == "heal" and user_role == "Doctor":
        if game.phase != "night":
            await query.answer("⚠️ Faqat tunda davolaysiz!", show_alert=True)
            return
            
        if game.doctor_target is not None:
            await query.answer("⚠️ Siz allaqachon birovni davoladingiz!", show_alert=True)
            return
            
        game.doctor_target = target_id
        await query.edit_message_text(f"💉 Siz {target.name} ni davoladingiz")
        await check_night_end(context, game)
        
    elif action == "check" and user_role == "Detective":
        if game.phase != "night":
            await query.answer("⚠️ Faqat tunda tekshirasiz!", show_alert=True)
            return
            
        if game.detective_target is not None:
            await query.answer("⚠️ Siz allaqachon birovni tekshirdingiz!", show_alert=True)
            return
            
        game.detective_target = target_id
        target_role = game.roles.get(target_id)
        is_mafia = target_role in ["Mafia", "Traitor"]
        await query.edit_message_text(
            f"🔍 Tekshiruv natijasi:\n"
            f"{target.name} {('mafiya azosi' if is_mafia else 'oddiy fuqaro')} ekan!"
        )
        await check_night_end(context, game)
        
    elif action == "vote":
        if game.phase != "day":
            await query.answer("⚠️ Faqat kunduzi ovoz bera olasiz!", show_alert=True)
            return
            
        if not game.get_player_by_id(user_id).is_alive:
            await query.answer("⚠️ O'lgan o'yinchilar ovoz bera olmaydi!", show_alert=True)
            return
            
        if user_id in game.votes:
            old_target = game.get_player_by_id(game.votes[user_id])
            if old_target:
                await context.bot.send_message(
                    chat_id=game.chat_id,
                    text=f"🔄 {query.from_user.first_name} ovozini {old_target.name}dan {target.name}ga o'zgartirdi!"
                )
        else:
            await context.bot.send_message(
                chat_id=game.chat_id,
                text=f"🗳 {query.from_user.first_name} {target.name}ga qarshi ovoz berdi!"
            )
            
        game.votes[user_id] = target_id
        await query.edit_message_text(f"🗳 Siz {target.name}ga qarshi ovoz berdingiz")
        
        # Check if all alive players have voted
        alive_players = game.get_alive_players()
        if len(game.votes) >= len([p for p in alive_players if p.id != target_id]):
            await process_day_results(context, game)

async def check_night_end(context: ContextTypes.DEFAULT_TYPE, game: Game) -> None:
    """Check if night phase should end"""
    mafia_count = len(game.get_players_by_role("Mafia"))
    doctor_exists = bool(game.get_players_by_role("Doctor"))
    detective_exists = bool(game.get_players_by_role("Detective"))
    
    night_complete = (
        len(game.mafia_votes) >= mafia_count and
        (not doctor_exists or game.doctor_target is not None) and
        (not detective_exists or game.detective_target is not None)
    )
    
    if night_complete:
        await process_night_results(context, game)

async def process_day_results(context: ContextTypes.DEFAULT_TYPE, game: Game) -> None:
    """Process day phase results"""
    # Count votes
    vote_counts = {}
    for target_id in game.votes.values():
        vote_counts[target_id] = vote_counts.get(target_id, 0) + 1
    
    # Find player with most votes
    target_id = max(vote_counts.items(), key=lambda x: x[1])[0] if vote_counts else None
    target = game.get_player_by_id(target_id) if target_id else None
    
    if target:
        target.is_alive = False
        await context.bot.send_message(
            chat_id=game.chat_id,
            text=f"⚖️ Ovoz berish natijasida {target.name} qatl etildi!"
        )
        
        # Check if target was Hunter
        if game.roles.get(target_id) == "Hunter":
            # Let Hunter choose their target
            await send_player_list_buttons(
                context, game.chat_id, target_id, "hunter",
                exclude_self=True
            )
    else:
        await context.bot.send_message(
            chat_id=game.chat_id,
            text="⚖️ Bugun hech kim qatl etilmadi..."
        )
    
    # Check game end condition
    if await check_game_end(context, game):
        return
    
    # Start night phase
    game.phase = "night"
    game.night_count += 1
    game.votes.clear()
    game.mafia_votes.clear()
    game.doctor_target = None
    game.detective_target = None
    
    await context.bot.send_message(
        chat_id=game.chat_id,
        text=f"🌙 Tun {game.night_count} boshlandi! Hamma uxlaydi..."
    )
    
    # Send action buttons to special roles
    for player in game.get_alive_players():
        role = game.roles.get(player.id)
        if role == "Mafia":
            await send_player_list_buttons(
                context, game.chat_id, player.id, "kill",
                exclude_self=True
            )
        elif role == "Doctor":
            await send_player_list_buttons(
                context, game.chat_id, player.id, "heal",
                exclude_self=False
            )
        elif role == "Detective":
            await send_player_list_buttons(
                context, game.chat_id, player.id, "check",
                exclude_self=True
            )

async def check_game_end(context: ContextTypes.DEFAULT_TYPE, game: Game) -> bool:
    """Check if game has ended"""
    alive_players = game.get_alive_players()
    mafia_count = len([p for p in alive_players if game.roles.get(p.id) in ["Mafia", "Traitor"]])
    village_count = len(alive_players) - mafia_count
    
    if mafia_count == 0:
        await context.bot.send_message(
            chat_id=game.chat_id,
            text="🎉 O'yin tugadi! Fuqarolar g'alaba qozondi!"
        )
        del games[game.chat_id]
        return True
    elif mafia_count >= village_count:
        await context.bot.send_message(
            chat_id=game.chat_id,
            text="🎭 O'yin tugadi! Mafiya g'alaba qozondi!"
        )
        del games[game.chat_id]
        return True
    return False

def main() -> None:
    """Start the bot"""
    # Load environment variables
    load_dotenv()
    token = os.getenv('BOT_TOKEN')
    if not token:
        logger.error("BOT_TOKEN topilmadi! .env faylini tekshiring.")
        return

    # Create application
    application = Application.builder().token(token).build()

    # Add handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("new", new_game))
    application.add_handler(CommandHandler("join", join_game))
    application.add_handler(CommandHandler("startgame", start_game))
    application.add_handler(CommandHandler("mode", set_mode))
    application.add_handler(CallbackQueryHandler(mode_callback, pattern="^mode_"))
    application.add_handler(CallbackQueryHandler(handle_player_action))

    # Start bot
    logger.info("Bot ishga tushdi...")
    application.run_polling()

if __name__ == '__main__':
    main()
