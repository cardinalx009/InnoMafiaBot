# Mafia Game Bot

A Telegram bot for playing the popular Mafia party game.

## Features
- Multiplayer game support
- Role distribution
- Day/Night cycles
- In-game shop system
- Player statistics
- Item system

## Setup Instructions

1. Clone this repository
```bash
git clone <your-repository-url>
cd mafia
```

2. Install dependencies
```bash
pip install -r requirements.txt
```

3. Create a `.env` file in the project root and add your Telegram Bot Token:
```
BOT_TOKEN=your_bot_token_here
```

4. Run the bot
```bash
python main.py
```

## Game Commands
- `/start` - Start the bot
- `/new_game` - Create a new game
- `/shop` - View shop items
- `/inventory` - Check your inventory
- `/stats` - View player statistics
- `/rules` - Show game rules

## Requirements
- Python 3.7+
- Dependencies listed in `requirements.txt`

## Note
Make sure to replace the BOT_TOKEN in the .env file with your own Telegram bot token obtained from [@BotFather](https://t.me/botfather).
